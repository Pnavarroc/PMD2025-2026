package com.alberto.examen.api

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.alberto.examen.R
import com.alberto.examen.api.adapter.PizzaAdapter
import com.alberto.examen.api.model.Pizza
import com.alberto.examen.api.model.RetrofitClient
import com.alberto.examen.databinding.ActivityApiBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ApiActivity : AppCompatActivity() {
    lateinit var binding: ActivityApiBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityApiBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.recyclerPizzas.layoutManager= LinearLayoutManager(this)


        cargarDatos()

    }

    private fun cargarDatos() {
        RetrofitClient.api.getMenu().enqueue(object : Callback<List<Pizza>> {

            override fun onResponse(
                call: Call<List<Pizza>>,
                response: Response<List<Pizza>>
            ) {
                if (response.isSuccessful) {

                    val lista = response.body() ?: emptyList()

                    binding.recyclerPizzas.adapter =
                        PizzaAdapter(lista)

                } else {
                    Toast.makeText(this@ApiActivity, "Error en API", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<Pizza>>, t: Throwable) {
                Toast.makeText(this@ApiActivity, "Error de conexión", Toast.LENGTH_SHORT).show()
            }
        })
    }
}