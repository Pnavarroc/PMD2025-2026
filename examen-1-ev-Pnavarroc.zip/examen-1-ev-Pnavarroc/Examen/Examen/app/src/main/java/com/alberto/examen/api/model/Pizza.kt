package com.alberto.examen.api.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Pizza (
    val name: String,
    val id: Int,
    val description: String,
    val image: String
) : Parcelable
