package com.alberto.examen.api.model

import retrofit2.Call
import retrofit2.http.GET

interface ApiService {

    @GET("v2/pizzas")

    fun getMenu(): Call<List<Pizza>>
}