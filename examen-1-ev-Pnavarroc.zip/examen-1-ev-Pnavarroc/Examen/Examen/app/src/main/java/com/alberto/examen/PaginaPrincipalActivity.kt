package com.alberto.examen

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.alberto.examen.api.ApiActivity
import com.alberto.examen.dataStore.SettingsActivity
import com.alberto.examen.databinding.ActivityPaginaPrincipalBinding

class PaginaPrincipalActivity : AppCompatActivity() {
    lateinit var binding: ActivityPaginaPrincipalBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityPaginaPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val nombreRecibido = intent.getStringExtra("Email_usuario")
        binding.tvBienvenida.text = "Bienvenido, $nombreRecibido"


        binding.btnEjercicio1.setOnClickListener {
            val intent = Intent(this, ApiActivity::class.java)
            startActivity(intent)
        }
        binding.btnEjercicio3.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

    }
}