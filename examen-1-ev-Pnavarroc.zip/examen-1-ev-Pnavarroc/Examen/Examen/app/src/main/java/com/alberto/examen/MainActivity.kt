package com.alberto.examen

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.alberto.examen.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import kotlin.toString

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        binding.btnIrAPaginaPrincipal.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val contrasena = binding.etContraseA.text.toString()

            //Miramos que no esten vacios los campos,
            if (email.isNotEmpty() && contrasena.isNotEmpty()) {

                val intent = Intent(this, PaginaPrincipalActivity::class.java)

                //Vamos a pasar la informacion al Bienvenido, pasamos solo el correo que es lo unico que nos hace falta.
                intent.putExtra("Email_usuario", email)
                startActivity(intent)
                finish()
            } else {
                //Si falta alguna variable sacamos un toast.
                Toast.makeText(this, "Debes de introducir el email y la contraseña", Toast.LENGTH_LONG).show()
            }

        }
    }
}