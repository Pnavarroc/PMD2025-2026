package com.alberto.examen.api.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.alberto.examen.api.model.Pizza
import com.alberto.examen.databinding.ItemPizzaBinding

class PizzaAdapter (val lista: List<Pizza>): RecyclerView.Adapter<PizzaViewHolder>(){
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PizzaViewHolder {
        val binding = ItemPizzaBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return PizzaViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: PizzaViewHolder,
        position: Int
    ) {
        holder.render(lista[position])
    }

    override fun getItemCount(): Int {
        return lista.size
    }

}