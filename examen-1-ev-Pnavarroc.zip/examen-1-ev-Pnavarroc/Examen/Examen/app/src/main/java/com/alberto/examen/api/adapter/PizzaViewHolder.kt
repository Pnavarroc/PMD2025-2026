package com.alberto.examen.api.adapter

import androidx.recyclerview.widget.RecyclerView
import com.alberto.examen.api.model.Pizza
import com.alberto.examen.databinding.ItemPizzaBinding
import com.squareup.picasso.Picasso

class PizzaViewHolder(val binding: ItemPizzaBinding) : RecyclerView.ViewHolder(binding.root) {

    fun render (pizza: Pizza){
        binding.tvNombrePizza.text = pizza.name
        binding.tvDescripcionPizza.text= pizza.description

        Picasso.get()
            .load(pizza.image)
            .into(binding.ivFotoPizza)
    }
}