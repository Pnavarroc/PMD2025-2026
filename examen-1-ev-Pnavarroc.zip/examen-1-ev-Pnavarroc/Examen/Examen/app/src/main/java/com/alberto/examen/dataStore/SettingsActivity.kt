package com.alberto.examen.dataStore

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.alberto.examen.R
import com.alberto.examen.databinding.ActivityApiBinding
import com.alberto.examen.databinding.ActivitySettingsBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    lateinit var binding: ActivitySettingsBinding
    private lateinit var pref: PreferencesManager
    private var firstTime: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding= ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //observarCambios()
        //configurarEventos()


    }
    private fun configurarEventos() {

            /*
            * val campo = binding.etCampo.text.toString()
            if (campo.isNotEmpty()) {
                lifecycleScope.launch {
                    pref.guardarNombre(campo)
                }
            }*/


        binding.swModDark.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch {
                pref.guardarModoOscuro(isChecked)
            }
        }

        binding.cbActivarNotificaciones.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch {
                pref.guardarNotificaciones(isChecked)
            }
        }

        binding.cbHabilitarSonido.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch {
                pref.guardarSonido(isChecked)
            }
        }
        binding.switchMaterial.setOnCheckedChangeListener { _, isChecked ->
            lifecycleScope.launch {
                pref.guardarSincronizacion(isChecked)
            }
        }


    }

    private fun observarCambios() {
        CoroutineScope(Dispatchers.IO).launch {
            pref.leerDatos.filter{firstTime}.collect { datos ->
                CoroutineScope(Dispatchers.Main).launch{
                    binding.cbHabilitarSonido.isChecked = datos.notificaciones
                    binding.swModDark.isChecked = datos.modoOscuro
                    binding.cbActivarNotificaciones.isChecked = datos.notificaciones
                    binding.switchMaterial.isChecked = datos.sincronizacion
                    firstTime =! firstTime
                }


            }
        }
    }
}


