package com.alberto.examen.dataStore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey

import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map


private val Context.dataStore by preferencesDataStore(name = "ajustes_usuario")

class PreferencesManager(private val context: Context){

    companion object {
        val NOTIFICACIONES = booleanPreferencesKey("notificaciones")
        val CAMPO = stringPreferencesKey("nombre")
        val MODO_OSCURO = booleanPreferencesKey("modo_oscuro")
        val SONIDO = booleanPreferencesKey("sonido")
        val SINCRONIZACION = booleanPreferencesKey("sincronizacion")
    }

    suspend fun guardarNombre(nombre: String) {
        context.dataStore.edit { prefs ->
            prefs[CAMPO] = nombre
        }
    }

    suspend fun guardarModoOscuro(activado: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[MODO_OSCURO] = activado
        }
    }
    suspend fun guardarNotificaciones(activado: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[NOTIFICACIONES] = activado
        }
    }
    suspend fun guardarSonido(activado: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[SONIDO] = activado
        }
    }
    suspend fun guardarSincronizacion(activado: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[SINCRONIZACION] = activado
        }
    }

    val leerDatos: Flow<UserSettings> = context.dataStore.data
        .map { prefs ->
            UserSettings(
                //campo = prefs[CAMPO] ?: "",
                modoOscuro = prefs[MODO_OSCURO] ?: false,
                notificaciones = prefs[NOTIFICACIONES] ?: false,
                sincronizacion = prefs[SINCRONIZACION] ?: false,
                sonido = prefs[SONIDO] ?: false,

            )
        }

}

data class UserSettings(
    //val campo: String,
    val modoOscuro: Boolean,
    val notificaciones: Boolean,
    val sincronizacion: Boolean,
    val sonido: Boolean,

)